O---------------------------------------O
|	INSTRUCTIONS FOR MAC USERS	|
O---------------------------------------O

Because directories on Mac use forward slashes (/) instead of backslashes (\) you will need to replace them all. 

Open megaman_9 V. 0.0.x.x as a project folder. Find all iterations of the FORWARD/(/) in all the files. DO NOT SEARCH FOR THE BACKSLASH.

Replace ALL ITERATIONS of the forward/with the following string: "/".

Next, find all iterations of the BACKSLASH. Replace with "/".

+---------------------------------------+
|	    COMPILING asm6.c 		|
+---------------------------------------+

Download Xcode from the App Store. You will need it to build .c files.
Open the terminal. This can be found by pressing command+space and typing in "terminal".
Ensure command-line tools are installed by entering the following into the terminal: "Xcode-select --install"
Enter "cd " into the terminal. INCLUDE THE SPACE!
DRAG AND DROP asm6.c into the terminal. Delete the name of the file off the end so that the text ends with a /
IF YOU ARE ON A NEWER VERSION OF MAC: 
Type in "clang asm6.c -o ASM6" into the terminal and press enter. 
Type in "./ASM6" to run ASM6 once.
IF THIS DOES NOT WORK FOR YOU:
Type in "gcc -Wall -o ASM6 asm6.c" into the terminal and press enter

+---------------------------------------+
|	USING ASM6 TO BUILD CODE	|
+---------------------------------------+

Open the terminal. This can be found by pressing command+space and typing in "terminal".
Type "cd " into the terminal. INCLUDE THE SPACE!
Drag and drop the file megaman.asm from the folder into the terminal. DELETE THE FILENAME AT THE END, leaving ONLY THE SLASH.
Press enter.
Cd stands for Change Directory, and what you have just Done is change your directory to the megaman_9 project folder. 

Ensure that ASM6.c is FULLY COMPILED before running. (If not, refer above)
DRAG AND DROP asm6 into the terminal. Add a space. 
ENTER THE FOLLOWING STRING: megaman.asm "megaman9 V. 0.0.1.2e.nes"
All errors should pop up. If no errors are present, the NES file will be written. 

Congratulations! Hope I was a help!

- Tortus